# __main__.py


def main():
    print("ota-installer is installed")


if __name__ == "__main__":
    main()
