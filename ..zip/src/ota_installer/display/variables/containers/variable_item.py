# src/ota_installer/display/variables/classes/variable_item.py
from collections import namedtuple

VariableItem = namedtuple("VariableItem", ["title", "value"])
